﻿# INSTALL.md

## Quick install (developer)
1. Open the project in VS Code.
2. Run 
pm install
3. For dev: 
pm run dev
4. For production build: 
pm run build
5. Static preview: open dist/index.html in your browser

Note: Environment variables are NOT included in this package. Add VITE_CONTACT_ENDPOINT locally before building if needed.
