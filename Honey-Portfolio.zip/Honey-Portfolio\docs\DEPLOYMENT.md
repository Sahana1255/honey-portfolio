﻿# DEPLOYMENT.md

## Deploy to Vercel (recommended)
1. 
pm i -g vercel (optional)
2. ercel and follow prompts, or use the GitHub integration.
3. Add VITE_CONTACT_ENDPOINT in the Vercel dashboard (Environment Variables).
